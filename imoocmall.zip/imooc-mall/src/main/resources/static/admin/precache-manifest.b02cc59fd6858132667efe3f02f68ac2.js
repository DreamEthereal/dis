self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dc10ad756e338cb6d7e17ceee275e571",
    "url": "/admin/index.html"
  },
  {
    "revision": "f6c529f00f0ebd78d2c6",
    "url": "/admin/static/css/2.bea6f0b1.chunk.css"
  },
  {
    "revision": "366cf6fa48bda77b3bdc",
    "url": "/admin/static/css/main.a389a5f9.chunk.css"
  },
  {
    "revision": "f6c529f00f0ebd78d2c6",
    "url": "/admin/static/js/2.a89f17b0.chunk.js"
  },
  {
    "revision": "4aa0fe1eaee3dcf45338a38641d40f08",
    "url": "/admin/static/js/2.a89f17b0.chunk.js.LICENSE"
  },
  {
    "revision": "366cf6fa48bda77b3bdc",
    "url": "/admin/static/js/main.3ba41d41.chunk.js"
  },
  {
    "revision": "e8da4dc9284736ad7ab7",
    "url": "/admin/static/js/runtime-main.5083273d.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/admin/static/media/logo.5d5d9eef.svg"
  }
]);